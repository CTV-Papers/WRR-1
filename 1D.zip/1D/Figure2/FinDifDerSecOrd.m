function [derivative] = FinDifDerSecOrd(N,Num,Den)

    derivative = zeros(size(Num,1),size(Num,2));
    
    %Left-sided finite difference scheme (first and second order)
    derivative(1,:) = ((Num(2,:))+(-1.*Num(1,:)))./(Den(2)-Den(1));
%     derivative(1,:) = ((-3.*Num(1,:))+(4.*Num(1+1,:))+(-1.*Num(1+2,:)))./(Den(1+2)-Den(1));
    
    %Right-sided finite difference scheme (first and second order)
    derivative(N,:) = ((Num(N,:))+(-1.*Num(N-1,:)))./(Den(N)-Den(N-1));
%     derivative(N,:) = ((3.*Num(N,:))+(-4.*Num(N-1,:))+(Num(N-2,:)))./(Den(N)-Den(N-2));
    
    %Central finite difference scheme second order:
    derivative(2:N-1,:) = ((Num(2+1:N,:))-(Num(2-1:N-2,:)))./repmat((Den(2+1:N)-Den(2-1:N-2)),[1,size(Num,2)]);

end