tic
clear variables
clc

%==========================================================================
%1D FAST FORWARD MODELING - 1ST ORDER PERTURBATION THEORY (BORN OR RYTOV)
%==========================================================================
%Steps:
%1. Modify 1DVWHF_IF input file to set the background medium
%2. Set ansol = 1 if computing ANA solutions in addition to NUM solution
%3. Set mode = 1 AND run background model to compute k-weighting function(PWF)
%4. Set bornrytov: 1st Order Born or 1st Order Rytov
%5. Set Actual Permeability Distribution and Actual Flow Rate Schedule
%6. Set output time (UTAWNS times or user-defined)
%7. Set mode = 2 AND run the Born Approximation
%==========================================================================
%Notes:
%The background medium can be homogeneous or heterogeneous.
%The flow history of background model consists of a single constant drawdown
%Time interpolations are pchip. Space interpolations are linear.
%==========================================================================
%MATLAB INPUT DATA

%Analytical Solution
ansol = 1;                  %ansol = 1: include analytical solution
                            %ansol = 1: only works if homogeneous background
                            
%Mode
mode = 1;                   %mode = 1: compute PWF of background in 1DVWHF_IF
                            %mode = 2: compute approximate solution of actual model

%____________________________
%DATA FOR MODE = 1

%Parallel and interpolation settings
num_workers = 4;            %Number of parallel workers
interp_method = 'lineal';   %interpolation method for first phase
                             
%____________________________
%DATA FOR BOTH MODES (1 AND 2)
%Output Time (hrs)
simuser = 2;                %Set to 1 for simulation times                
to = logspace(-3,0,15);     %If simuser /= 1 -> Time at which the calculations (Wr and P) are done

%____________________________
%DATA FOR MODE = 2
%Approximate Solution
bornrytov = 1;              %bornrytov = 1: 1st Order Born Approximation (suitable for heterogeneous media using 1-ko/k)
                            %bornrytov = 2: 1st Order Rytov Approximation (suitable for homogeneous media using log(k/ko))

normalog = 1;               %normalog = 1: [1-(ko/k)] -> suitable for heterogeneous media using Born approximation   
                            %normalog = 2: [log(k/ko)] -> suitable for homogeneous media using Rytov approximation 

smoothdata = 1;             %smoothdata = 1: smooth approximation  
spanpts = 5;                %Number of span points to smooth about PSF ET-LT coupling

%Permeability Distribution 
rdisto = [4.25/12 10];         %Radii Distribution (Follow 1DVWHF) (ft) [4.25/12 1.5*4.25/12];
kdisto = [5 25];              %Permeability Distribution (Follow 1DVWHF) (md) 

%Flow Rate Schedule
qvv = [10];                 %Flow Rate corresponding to tpv (numel(qvv) = numel(tpv)) (B/D)
tpv = [0];                  %Time at which flow rate in changed (tpv(1) = 0) (min)
interpts = 1000;            %Points for Interpolation


%==========================================================================
%MAIN CODE

%__________________________________________________________________________
%CONVERSION UNITS - FROM OIL FIELD UNITS TO A CONSISTENT SYSTEM

in2ft = 0.083333333333333;
ft2m = 0.3048;
cp2Pas = 0.001;
psi2Pa = 6894.7572931684;
Pa2psi = 0.00014503773773021;
md2m2 = 9.869233e-16;
d2sec = 86400;
min2sec = 60;
bbl2m3 = 0.15898756717225;
sec2hrs = 0.00027777777777778;
bbl2ft3 = 5.6145835124493;

% parpool('myProf',8)
if mode == 1 
    
    %======================================================================
    %RUNNING BACKGROUND MODEL WITH FORTRAN CODE
    
    system('1DVWHF.exe'); 

    %======================================================================
    %READING FILES

    [PD] = importdata('PressureDataOF.txt');        %[psi]
    [tv] = importdata('TimeDataOF.txt');            %[hrs]
    [gprm] = importdata('GridPointRadiusOF.txt');   %[ft]
    
    tso = tv(:,1)';                                 %Time [hrs]
    rr = gprm(:,1);                                 %Space gridding [ft]
    
    if simuser == 1
        to = tso;                                   %Output Time [hrs]
    end

    %======================================================================
    %BACKGROUND MEDIUM PROPERTIES

    fileID = fopen('1DVWHF_IF.txt','r');
    InputData = textscan(fileID,'%s %*[^\n]');
    
    InputData = InputData{:,1};
    fclose(fileID);

    %Geometry
    rwo = str2double(InputData{1})/12;              %Formation radius (ft)
    reo = str2double(InputData{2});                 %Drainage radius (ft)
    dzo = str2double(InputData{3});                 %Formation tickness (ft)

    %Fluid properties
    fvf = str2double(InputData{15});                %Formation Volume Factor
    muo = str2double(InputData{17});                %Viscosity (cp)
    cfo = str2double(InputData{19});                %Fluid compressibility (psi-1)

    nprz = str2double(InputData{21});               %Number of petrophysical radial zones

    ct1 = 21+1+nprz;
    ct2 = ct1 + nprz;
    ct3 = ct2 + nprz;
    %Rock properties
    for i = 1:nprz
        koo(i) = str2double(InputData{ct1});        %Permeability - background medium (md)
        phi(i) = str2double(InputData{ct2});        %Porosity (fraction)
        cro(i) = str2double(InputData{ct3});        %Rock compressibility (psi-1)
        ct1 = ct1 + 1;
        ct2 = ct1 + nprz; 
        ct3 = ct2 + nprz;
    end
    %Initial and boundary conditions
    Pio = str2double(InputData{27+(nprz*4)});       %Initial pressure (psi)
    nrc = str2double(InputData{38+(nprz*4)});       %Number of Rate Changes
    qo = str2double(InputData{39+(nprz*4)+nrc});    %Flow Rate (B/D)
    
    cto = cfo+cro;                                  %Total compressibility (psi-1)
       
    %______________________________________________________________________
    %CONSISTENT UNITS AND DIMENSIONLESS VARIABLES
    
    tcu = to/sec2hrs;
    tscu = tso/sec2hrs;
    rrcu = rr*ft2m;
    PDcu = PD*psi2Pa;
    
    rwcu = rwo*ft2m;
    recu = reo*ft2m;
    dzcu = dzo*ft2m;
    mucu = muo*cp2Pas;
    cfcu = cfo/psi2Pa;
    kcu = koo*md2m2;
    crcu = cro/psi2Pa;
    ctcu = cto/psi2Pa;
    Picu = Pio*psi2Pa;
    qcu = qo*bbl2m3/d2sec;
    
    td = (kcu(1)*tcu)/(phi(1)*mucu*ctcu(1)*(rwcu^2));
    tds = (kcu(1)*tscu)/(phi(1)*mucu*ctcu(1)*(rwcu^2));
    rd = rrcu/rwcu;
    
    %td = (0.000264*koo(1)*to)/(phi(1)*muo*cto(1)*(rwo^2));
    %tds = (0.000264*koo(1)*tso)/(phi(1)*muo*cto(1)*(rwo^2));
    %rd = rr/rwo;

    %======================================================================
    %FIRST PART OF THE PERMEABILITY SENSITIVITY FUNCTION
    
    %Analytical Permeability Weighting Function
    %------------------------------------------
    
    if ansol == 1
        
        %Analytical Weighting Function - Laplace-Domain-Derived
        [rdm, tdm] = meshgrid(rd, td);
        Wrald = real((-1.*rdm./(2.*tdm)).*exp(-1.*(rdm.^2)./(2.*tdm)).*besselk(1,(-1.*(rdm).^2)./(2.*tdm)));

        %Analytical Weighting Function - Time-Domain-Derived
        for j = 1:length(td)
            for i = 1:length(rd)

                %Wrfun = @(ta) (rd(i).*((-1/rd(i)).*exp(-1.*(rd(i).^2)./(4.*ta))).*((-1*rd(i)./(4.*((td(j)-ta).^2))).*exp(-1.*(rd(i).^2)./(4.*(td(j)-ta)))));
                Wrfun = @(ta) (((-1/rd(i)).*exp(-1.*(rd(i).^2)./(4.*ta))).*((-1*rd(i)./(4.*((td(j)-ta).^2))).*exp(-1.*(rd(i).^2)./(4.*(td(j)-ta)))));
                Wratd(j,i) = integral(Wrfun,0,td(j))*((rwcu/(2*pi*dzcu))^2);
                %Wratd(j,i) = integral(Wrfun,0,td(j));

            end
        end
        
    end
    
    %Central Finite Difference Location
    %----------------------------------
    
    tdsdiff = tds(1:length(tds)-1)+diff(tds)./2;                                  %Assigning as if central finite difference
    rddiff = rd(1:length(rd)-1)+diff(rd)./2;                                      %Assigning as if central finite difference
    
    %Numerical Pdo
    %---------------
    
    Pdonum = (kcu(1).*rwcu.*(Picu-PDcu)./sum(qcu))./(fvf.*mucu);
    %Pdonum = (koo(1).*dzo.*(Pio-PD)./qo)./(141.2.*fvf.*muo);
        
    %Gradient of Pdo @ tds (linear extrapolation)
    %--------------------------------------------

    GradPdonum1 = FinDifDerSecOrd(length(rd),Pdonum,rd);
    GradPdonum1 = GradPdonum1(2:length(rd)-1,:);
    GradPdonum = interp1(rd(2:length(rd)-1),GradPdonum1,rd,'linear','extrap')';
    
    %Sensitivity Function: rd*convint(GradPdonum*GradGdonum)
    %-------------------------------------------------------
    
    %Create parallel pool
    %---------------------------------
%     local_pool = parpool(num_workers);
    
    GradPdonum(1,:) = [];
    
    TD1 = tds(2:length(tds));
    Wrnum = zeros(length(TD1),size(PD,1));
    
    for j = 1:size(PD,1)
        
        Pd1 = GradPdonum(:,j);
        PdM = zeros(length(TD1),length(TD1));
        PdM(:,1) = Pd1;
        DPd1 = zeros(length(TD1),1);
        DPd1(1) = Pd1(1);
        DPd1(2:length(TD1),1) = diff(Pd1);

        for i = 2:length(TD1)
            td1tmp = TD1(i:length(TD1))-TD1(i-1);
            PdM(i:length(TD1),i) = interp1(TD1,Pd1,td1tmp,interp_method,'extrap');
        end
        
        %Wrnum(:,j) = rd(j).*(PdM*DPd1);
        Wrnum(:,j) = (PdM*DPd1);
        
    end
    
    %Close parallel pool
    %---------------------------------
%     delete(local_pool);
    
    Wrnum(Wrnum<0) = 0;
    Wrnum = vertcat(zeros(1, size(PD,1)), Wrnum);
    
    Wrnum = interp1(tds,Wrnum,td,'linear','extrap');

    %======================================================================
    %SAVING PERMEABILITY WEIGHTING FUNCTIONS
    
    fid = fopen('KWeightingFunctionNum.txt','wt');
    dlmwrite('KWeightingFunctionNum.txt',Wrnum)
    fclose(fid);

    if ansol == 1
        
        fid = fopen('KWeightingFunctionALD.txt','wt');
        dlmwrite('KWeightingFunctionALD.txt',Wrald) 
        fclose(fid);
        
        fid = fopen('KWeightingFunctionATD.txt','wt');
        dlmwrite('KWeightingFunctionATD.txt',Wratd)
        fclose(fid);

    end
    
    PSFa = reshape(Wratd,size(Wratd,1)*size(Wratd,2),1);
    PSFn = reshape(Wrnum,size(Wratd,1)*size(Wratd,2),1);
    p = 2;
    
    PSFerror = norm((PSFa(1:end)-PSFn(1:end)),p);
    PSFanorm = norm((PSFa(1:end)),p);
    RelError = 100*(PSFerror/PSFanorm);
    
    save('WRR1_Data_Fig2','Wrnum', 'Wratd', 'rr', 'td', 'RelError')
    
    %======================================================================
    %PLOTTING PERMEABILITY WEIGHTING FUNCTIONS

    figure
    if ansol == 1
%         for i = 1:length(td)
%             ald(i) = loglog(rd,Wrald(i,:),'-g','LineWidth',2.5);
%             hold on
%         end
        for i = 1:length(td)
            atd(i) = loglog(rr,Wratd(i,:),'-k','LineWidth',2.5);
            hold on
        end
    end
    for i = 1:length(td)
        n(i) = loglog(rr,Wrnum(i,:),'-r','LineWidth',2.5) ;
        hold on
    end
    grid on
%     title('Permeability Sensitivity Function','fontname','calibri','fontweight','bold','fontsize',18)
    xlabel('Radial Distance [ft]','fontname','calibri','fontweight','bold','fontsize',16)
    ylabel('Dimensionless PSF','fontname','calibri','fontweight','bold','fontsize',16)
%     xlim([1e0 1e2])
    ylim([1e-10 1e-5])
    if ansol == 1
        legend([atd(1),n(1)],'Analytical','Numerical','Location','northeast')
    else
        legend([n(1)],'Numerical','Location','northeast')
    end
    set(gcf,'color','w')
    set(gca,'fontname','calibri','FontSize',12)    
    
    gpd = linspace(0,dzo/rwo,2);
    rc = zeros(length(rd)*length(gpd),1);
    zc = zeros(length(rd)*length(gpd),1);
    ct = 0;
    for i = 1:size(rd)
        for j = 1:size(gpd,2)
            ct = ct + 1;
            rc(ct) = rd(i);
            zc(ct) = gpd(j);
        end
    end
    Wspat = Wrnum(length(td),:)';
    [RadiiQuery,DepthQuery] = meshgrid(rd,linspace(min(gpd),max(gpd),1000));
    Wspat = horzcat(Wspat,Wspat);
    Wspat = reshape(Wspat',[2*length(Wrnum(length(td),:)'),1]);
    WQuery = griddata(rc,zc,Wspat,RadiiQuery,DepthQuery);
    
    figure
    h = pcolor(RadiiQuery,DepthQuery,(WQuery));
    c = colorbar;
    limits = [min(min(Wspat)) max(max(Wspat))];
    caxis((limits))
    title('Permeability Sensitivity Function','fontname','calibri','fontweight','bold','fontsize',18)
    xlabel('Dimensionless Radial Distance','fontname','calibri','fontweight','bold','fontsize',16)
    xlim([rd(1) rd(size(rd,1))])
    set(h, 'EdgeColor', 'none')
    set(gca,'YDir','reverse')
    set(gca,'XScale','Log')
    set(gca,'ytick',[])
    set(gcf,'color','w')
    set(gca,'fontname','calibri','FontSize',12)
    colormap jet;
    c.Label.String = 'Dimensionless PSF';
    c.Label.FontSize = 12;
    
    if ansol == 1
        Wspat = Wratd(length(td),:)';
        [RadiiQuery,DepthQuery] = meshgrid(rr,linspace(min(gpd),max(gpd),1000));
        Wspat = horzcat(Wspat,Wspat);
        Wspat = reshape(Wspat',[2*length(Wratd(length(td),:)'),1]);
        WQuery = griddata(rc,zc,Wspat,RadiiQuery,DepthQuery);

        figure
        h = pcolor(RadiiQuery,DepthQuery,WQuery);
        caxis([min(min(Wspat)) max(max(Wspat))])
        c = colorbar;
        title('Permeability Sensitivity Map - Analytical','fontweight','bold','fontsize',18)
        xlabel('Radial Distance [ft]','fontweight','bold','fontsize',16)
        xlim([rr(1) rr(size(rr,1))])
        set(h, 'EdgeColor', 'none')
        set(gca,'YDir','reverse')
        set(gca,'XScale','Log')
        set(gca,'ytick',[])
        set(gcf,'color','w')
        set(gca,'FontSize',12)
        colormap jet;
        c.Label.String = 'PSF - Dimensionless';
        c.Label.FontSize = 12;
    end
    
elseif mode == 2
    
    %======================================================================
    %READING FILES

    [PD] = importdata('PressureDataOF.txt');        
    [tv] = importdata('TimeDataOF.txt');           
    [gprm] = importdata('GridPointRadiusOF.txt'); 

    Wrnum = importdata('KWeightingFunctionNum.txt');
    if ansol == 1
        Wrald = importdata('KWeightingFunctionALD.txt');
        Wratd = importdata('KWeightingFunctionATD.txt');
        Wratd(isnan(Wratd)) = 0; 
        Wrald(isnan(Wrald)) = 0; 
    end
    
    tso = tv(:,1)';                                 %Time [hrs]
    rr = gprm(:,1);                                 %Space gridding [ft]
    
    if simuser == 1
        to = tso;                                   %Output Time [hrs]
    end

    %======================================================================
    %BACKGROUND MEDIUM PROPERTIES

    fileID = fopen('1DVWHF_IF.txt','r');
    InputData = textscan(fileID,'%s %*[^\n]');
    
    InputData = InputData{:,1};
    fclose(fileID);

    %Geometry
    rwo = str2double(InputData{1})/12;              %Formation radius (ft)
    reo = str2double(InputData{2});                 %Drainage radius (ft)
    dzo = str2double(InputData{3});                 %Formation tickness (ft)

    %Fluid properties
    fvf = str2double(InputData{15});                %Formation Volume Factor
    muo = str2double(InputData{17});                %Viscosity (cp)
    cfo = str2double(InputData{19});                %Fluid compressibility (psi-1)

    nprz = str2double(InputData{21});               %Number of petrophysical radial zones

    ct1 = 21+1+nprz;
    ct2 = ct1 + nprz;
    ct3 = ct2 + nprz;
    %Rock properties
    for i = 1:nprz
        koo(i) = str2double(InputData{ct1});        %Permeability - background medium (md)
        phi(i) = str2double(InputData{ct2});        %Porosity (fraction)
        cro(i) = str2double(InputData{ct3});        %Rock compressibility (psi-1)
        ct1 = ct1 + 1;
        ct2 = ct1 + nprz; 
        ct3 = ct2 + nprz;
    end
    %Initial and boundary conditions
    Pio = str2double(InputData{27+(nprz*4)});       %Initial pressure (psi)
    qo = str2double(InputData{39+(nprz*4)});        %Flow Rate (B/D)
    
    cto = cfo+cro;                                  %Total compressibility (psi-1)

    %======================================================================
    %DIMENSIONLESS VARIABLES
    
    td = (0.000264*koo(1)*to)/(phi(1)*muo*cto(1)*(rwo^2));
    tds = (0.000264*koo(1)*tso)/(phi(1)*muo*cto(1)*(rwo^2));
    rd = rr/rwo;
    rd1 = rdisto/rwo;
    rd1(1) = 1;
    rd1 = horzcat(rd1,reo/rwo);
    
    %======================================================================
    %ANOMALY FUNCTION
    
    for i = 2:length(rd1)
    
        if ansol == 1
            
            rdv = logspace(log10(rd1(i-1)),log10(rd1(i)),1000);
            
            WraldInt = interp1(rd,Wrald',rdv,'pchip','extrap'); 
            Pwd1ld(i-1,:) = log(kdisto(i-1)/koo(1))*trapz(rdv,WraldInt);

            WratdInt = interp1(rd,Wratd',rdv,'pchip','extrap'); 
            Pwd1td(i-1,:) = log(kdisto(i-1)/koo(1))*trapz(rdv,WratdInt);
            
        end
        
        if length(rdisto) == 1
            rdv = logspace(log10(rd1(i-1)),log10(rd1(i)),1000);                     %BEST SPATIAL DISCRETIZATION FOR HOMOGENEOUS MEDIA USING RYTOV APPROXIMATION
            WrnInt = interp1(rd,Wrnum',rdv,'pchip','extrap'); 
        else
            rdv = linspace((rd1(i-1)),(rd1(i)),1000);                               %BEST SPATIAL DISCRETIZATION FOR HETEROGENEOUS MEDIA USING BORN APPROXIMATION ??? (SEEMS TO BE THE SAME AS LOGSPACE)
            WrnInt = interp1(rd,Wrnum',rdv,'linear','extrap'); 
        end
                
        if nprz == 1
            if normalog == 1
                Pwd1num(i-1,:) = (1-(koo(1)/kdisto(i-1)))*trapz(rdv,WrnInt,1);      %BEST DEFINITION FOR HETEROGENEOUS MEDIA USING BORN APPROXIMATION
            elseif normalog == 2
                Pwd1num(i-1,:) = log(kdisto(i-1)/koo(1))*trapz(rdv,WrnInt,1);       %BEST DEFINITION FOR HOMOGENEOUS MEDIA USING RYTOV APPROXIMATION
            end
        else
            if normalog == 1
                Pwd1num(i-1,:) = (1-(koo(i-1)/kdisto(i-1)))*trapz(rdv,WrnInt,1);    %BEST DEFINITION FOR HETEROGENEOUS MEDIA USING BORN APPROXIMATION
            elseif normalog == 2
                Pwd1num(i-1,:) = log(kdisto(i-1)/koo(i-1))*trapz(rdv,WrnInt,1);     %BEST DEFINITION FOR HOMOGENEOUS MEDIA USING RYTOV APPROXIMATION
            end
        end
        
    end
    
    if ansol == 1
        Pwd1ld = sum(Pwd1ld,1);
        Pwd1td = sum(Pwd1td,1);
    end
    Pwd1num = sum(Pwd1num,1);
    
    %======================================================================
    %FIRST ORDER PERTURBATION THEORY (BORN OR RYTOV)
    
    if ansol == 1
        Pwdold = -0.5.*ei(-1./(4.*td));
        if bornrytov == 1
            Pwdld = Pwdold - Pwd1ld;
        elseif  bornrytov == 2
            Pwdld = Pwdold.*exp(-1.*Pwd1ld./Pwdold);
        end
        Pwld = Pio - ((Pwdld.*141.2.*qo.*fvf.*muo)./(koo(1).*dzo));
        Pwld(1) = Pio;
        
        Pwdotd = -0.5.*ei(-1./(4.*td));
        if bornrytov == 1
            Pwdtd = Pwdotd - Pwd1td;
        elseif  bornrytov == 2
            Pwdtd = Pwdotd.*exp(-1.*Pwd1td./Pwdotd);
        end
        Pwtd = Pio - ((Pwdtd.*141.2.*qo.*fvf.*muo)./(koo(1).*dzo));
        Pwtd(1) = Pio;
    end
    
    for i = 1:length(td)
        [~,idx(i)] = min(abs(tds-td(i)));
    end
    
    Pwnumbck = PD(1,idx);
    Pwdonum = ((koo(1).*dzo./(141.2.*qo.*fvf.*muo)).*(Pio-Pwnumbck));
    if bornrytov == 1
        Pwdnum = Pwdonum - Pwd1num;
    elseif bornrytov == 2
        Pwdnum = Pwdonum.*exp(-1.*Pwd1num./Pwdonum);
        Pwdnum(isnan(Pwdnum)) = 0;
    end
    Pwnum = Pio - ((Pwdnum.*141.2.*qo.*fvf.*muo)./(koo(1).*dzo));
    
    if smoothdata == 1
        [~,idxs3] = find(to > etlt);
        idxt = idxs3(1);
        %Pwnum = smooth(Pwnum,'moving');
        %Pwdnum = smooth(Pwdnum,'moving');
        Pwnum(idxt-(spanpts+1):idxt+spanpts) = smooth(Pwnum(idxt-(spanpts+1):idxt+spanpts),spanpts,'moving');
        Pwdnum(idxt-(spanpts+1):idxt+spanpts) = smooth(Pwdnum(idxt-(spanpts+1):idxt+spanpts),spanpts,'moving');
    end
    
    %======================================================================
    %CONVOLUTION THEORY
       
    %Interpolation
    %-------------    
    tgo = to;
    ggo = deconv((Pio-Pwnum),qo);
    %tg = linspace(to(1),to(length(to)),interpts);
    tg = logspace(log10(to(2)),log10(to(length(to))),interpts);
    tg = horzcat(0,tg);
    gg = interp1(tgo,ggo,tg,'pchip','extrap');
    
    tpv = tpv/60; %Mins to Hrs
    
    %Fast Forward Modeling: DP for Q History from Green's Function
    %-------------------------------------------------------------
    QM = zeros(length(qvv),length(qvv));
    TM = zeros(length(qvv),length(qvv));
    for i = 1:length(qvv)

        QM(i,1:i) = qvv(1:i);
        TM(i,1:i) = tpv(1:i);
        [~,idxtp] = min(abs(tg-tpv(i)));
        if tg(idxtp) > tpv(i)
            idxtp = idxtp-1;
        end
        idxtps(i) = idxtp;

    end

    ct = 0;
    for i = 1:length(qvv)

        if length(qvv) > 1
            if i == 1
                TV{i} = tg(idxtps(i):idxtps(i+1));
            elseif i == length(qvv)
                TV{i} = tg(idxtps(i)+1:length(tg));
            else
                TV{i} = tg(idxtps(i)+1:idxtps(i+1));
            end
        else
            TV{i} = tg(idxtps(i):length(tg));
        end

        for j = 1:i

            ct = ct + 1;
            TVdiff{ct} = TV{i}-tpv(j);

            for jj = 1:length(TVdiff{ct})

                [~,idxtmp] = min(abs(tg-TVdiff{ct}(jj)));
                idxdiff{ct}(jj) = idxtmp;

            end

        end

        if i == 1
            qvvnz{i} = qvv(i);
        else
            qvvnz{i} = horzcat(qvvnz{i-1},qvv(i)-qvv(i-1));
        end

    end

    qvvext = qvvnz{1};
    for i = 1:length(qvv)-1
        qvvext = horzcat(qvvext,qvvnz{i+1});
    end

    ct = 0;
    for i = 1:length(qvv)

        for j = 1:i

            ct = ct + 1;
            DPffm{ct} = conv(gg(idxdiff{ct}),qvvext(ct));   

        end
        DPffmc{i} = zeros(1,length(TV{i}));

    end

    ct = 0;
    for i = 1:length(qvv)

        for j = 1:i

            ct = ct + 1;
            if ct == 1
                DPffmc{i} = DPffm{ct};
            else
                DPffmc{i} = DPffmc{i} + DPffm{ct};                  
            end

        end

    end
    
    %Final Product: Rytov/Born Approximation + Convolution Theory
    %-------------------------------------------------------------
    DPffmfinal = DPffmc{1};
    parfor i = 1:length(qvv)-1
        DPffmfinal = horzcat(DPffmfinal,DPffmc{i+1});
    end
    Pwffm = Pio-DPffmfinal;  
    tlog = tg;
    
    %======================================================================
    %FLOW RATE AND BOUNDARY CONDITION VECTOR - (POST PROCESSING PURPOSES)
    clear idx
    idx(1) = 0;
    qvc = [];
    tpvt = horzcat(tpv,tlog(length(tlog)));
    for i = 2:length(tpvt)
        idxt = find((tpvt(i)>=tlog));
        idx(i) = idxt(end);
        qvc = vertcat(qvc,qvv(i-1)*ones(idx(i)-idx(i-1),1));
    end
    
    nrc = length(qvv);
    bcv(1) = nrc;
    for i = 1:nrc
        bcv = vertcat(bcv,qvv(i));
    end
    for i = 2:nrc+1
        bcv = vertcat(bcv,tpvt(i)*60);
    end
    for i = 1:nrc
        bcv = vertcat(bcv,0);
    end
    
    %======================================================================
    %SAVING FAST FORWARD MODELING PRESSURE and FLOW RATE AT TOOL
    
    dlmwrite('PressureAtToolFFM.txt',horzcat(tlog',Pwffm'),'precision',5);
    dlmwrite('FlowRateAtToolFFM.txt',qvc);
    dlmwrite('BoundaryConditionsFFM.txt',bcv);
    
    %======================================================================
    %PLOTTING RESULTS
    
    %Born Approximation (1st Order Perturbation Theory) - Dimensionless
    %------------------------------------------------------------------
    figure
    if ansol == 1
        ald = semilogx(td,Pwdld,'xg','LineWidth',2.5);
        hold on
        atd = semilogx(td,Pwdtd,'ob','LineWidth',2.5);
        hold on
    end
    num = semilogx(td,Pwdnum,'-r','LineWidth',2.5);
    grid on
    if bornrytov == 1
        title('Born - Background Q - Dimensionless','fontweight','bold','fontsize',18)
    elseif bornrytov == 2
        title('Rytov - Background Q - Dimensionless','fontweight','bold','fontsize',18)
    end
    xlabel('td','fontweight','bold','fontsize',16)
    ylabel('Pwd','fontweight','bold','fontsize',16)
    if ansol == 1
        legend([ald atd, num],'Analytical Laplace', 'Analytical Time','Numerical','Location','southeast')
    else
        legend([num],'Numerical','Location','northeast')
    end
    set(gcf,'color','w')
    set(gca,'FontSize',12) 
    
    %Born Approximation (1st Order Perturbation Theory)
    %--------------------------------------------------
    figure
    if ansol == 1
        ald = semilogx(to,Pwld,'xg','LineWidth',2.5);
        hold on
        atd = semilogx(to,Pwtd,'ob','LineWidth',2.5);
        hold on
    end
    
    num = semilogx(to,Pwnum,'-r','LineWidth',2.5);
    grid on
    if bornrytov == 1
        title('Born - Background Q ','fontweight','bold','fontsize',18)
    elseif bornrytov == 2
        title('Rytov - Background Q ','fontweight','bold','fontsize',18)
    end
    xlabel('Time [hrs]','fontweight','bold','fontsize',16)
    ylabel('Pressure [psi]','fontweight','bold','fontsize',16)
    if ansol == 1
        legend([ald, atd, num],'Analytical Laplace', 'Analytical Time','Numerical','Location','southeast')
    else
        legend([num],'Numerical','Location','northeast')
    end
    set(gcf,'color','w')
    set(gca,'FontSize',12) 
    
    %Born Approximation for User-defined Flow Rate History
    %-----------------------------------------------------
    figure
    plot(tlog,Pwffm,'or','LineWidth',2.5) 
    grid on
    if bornrytov == 1
        title('Born & Convolution','fontweight','bold','fontsize',18)
    elseif bornrytov == 2
        title('Rytov & Convolution','fontweight','bold','fontsize',18)
    end
    xlabel('Time [hrs]','fontweight','bold','fontsize',16)
    ylabel('Pressure [psi]','fontweight','bold','fontsize',16)
    set(gcf,'color','w')
    set(gca,'FontSize',12)
    hold on
    
    figure
    [hAx,hLine1,hLine2] = plotyy(tlog,Pwffm,tlog,qvc);
    grid on
    title('History Plot','fontweight','bold','fontsize',18)
    xlabel('Time [hrs]','fontweight','bold','fontsize',16)
    ylabel(hAx(1),'Pressure [psi]','fontweight','bold','fontsize',16) 
    ylabel(hAx(2),'Flow Rate [bpd]','fontweight','bold','fontsize',16)
    set(hLine1,'Color',[1,0,0],'linewidth',2.5)
    set(hLine2,'Color',[0,0,1],'linewidth',2.5)
    set(hAx(1),'YColor',[1,0,0])
    set(hAx(2),'YColor',[0,0,1])
    set(gca,'FontSize',12)
    set(hAx(2),'FontSize',12)
    set(gcf,'color','w')
    
end

toc


