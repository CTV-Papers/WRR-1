%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Professional Matlab Figures Suite   %%%%%%%%%%
%%%%%%% David Medellin, Ph.D.               %%%%%%%%%%
%%%%%%% Joint Industry Research Consortium  %%%%%%%%%%
%%%%%%% The University of Texas at Austin   %%%%%%%%%%
%%%%%%% 2016/06/01                          %%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Add Paths
%__________________________________________________________________________
addpath('exportfig')            %https://www.mathworks.com/matlabcentral/fileexchange/23629-export-fig
addpath('tightfig')             %https://www.mathworks.com/matlabcentral/fileexchange/34055-tightfig
addpath('xpdfbin-win-3.04')     %http://www.foolabs.com/xpdf/download.html

%Read Data
%__________________________________________________________________________
load('WRR1_Data_Fig2')

Wratdo = Wratd;
Wrnumo = Wrnum;

Wrnumo(abs(Wrnumo)<=1e-15) = 1;
Wrnumtt = log10(abs(Wrnumo));
Wrnumt1 = sign(Wrnumo).*(Wrnumtt);
Wrnum = Wrnumt1;

Wrnum(Wrnumt1>0) = Wrnumt1(Wrnumt1>0)-(0.00+max(max(max(Wrnumt1(Wrnumt1>0)))));
Wrnum(Wrnumt1<0) = Wrnumt1(Wrnumt1<0)-(-0.00+min(min(min(Wrnumt1(Wrnumt1<0)))));

Wratdo(abs(Wratdo)<=1e-15) = 1;
Wratdtt = log10(abs(Wratdo));
Wratdt1 = sign(Wratdo).*(Wratdtt);
Wratd = Wratdt1;

Wratd(Wratdt1>0) = Wratdt1(Wratdt1>0)-(0.00+max(max(max(Wratdt1(Wratdt1>0)))));
Wratd(Wratdt1<0) = Wratdt1(Wratdt1<0)-(-0.00+min(min(min(Wratdt1(Wratdt1<0)))));

%Create Figure
%__________________________________________________________________________
width=15;                       %in centimeters
height=10;                      %in centimeters
figurefontsize=16;
legendfontsize=20;
linewidthplot = 2.5;
xl = 1e-1;
xu = 1e2;
yl = 1e-10;
yu = 1e-5;

%Figure Settings
figure('Units','centimeters',...
'Position',[3 3 width height],...
'PaperPositionMode','auto');

%Graph Settings
set(gca,...
'Units','normalized',...
'Position',[.15 .2 .75 .7],...
'FontUnits','points',...
'FontWeight','normal',...
'FontSize',figurefontsize,...
'FontName','Times New Roman')

%Figure Plot
for i = 1:length(td)
    atd(i) = loglog(rr,Wratd(i,:),'-k','LineWidth',linewidthplot);
    hold on
end
for i = 1:length(td)
    n(i) = loglog(rr,Wrnum(i,:),'-r','LineWidth',linewidthplot) ;
    hold on
end
grid on

%Y-label
ylabel('Dimensionless PSF',...
'FontUnits','points',...
'interpreter','latex',...
'FontSize',figurefontsize,...
'FontWeight','normal',...
'FontName','Times New Roman');
ylim([3 10]);

%X-label
xlabel('Radial Distance [ft]',...
'FontUnits','points',...
'interpreter','latex',...
'FontSize',figurefontsize,...
'FontWeight','normal',...
'FontName','Times New Roman');
% xlim([xl xu]);

%Title
% title('Permeability Sensitivity Function',...
% 'FontUnits','points',...
% 'FontSize',figurefontsize,...
% 'FontWeight','bold',...
% 'FontName','Times New Roman');

%Legend
legend([atd(1),n(1)],{'Analytical','Numerical'},'Location','northeast',...
'FontUnits','points',...
'interpreter','latex',...
'interpreter','latex',...
'FontSize',legendfontsize,...
'FontName','Times New Roman');

set(gcf,'color','w');
tightfig

%RelativeError
%__________________________________________________________________________
disp(['The Relative Error is', ' ', num2str(round(RelError,2)), '%']);

%Export in various formats
%__________________________________________________________________________
fn1 = 'WRR1_Figure2';
fn2 = num2str(round(RelError,2));
filename = [fn1 '_RelError' fn2];
% export_fig 'Figure' -jpg -m10 -painters
export_fig 'WRR1_Figure2_Dis' -png -m10 -opengl
% export_fig 'Figure' -eps -m10 -painters


